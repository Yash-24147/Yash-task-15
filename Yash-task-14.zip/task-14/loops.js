console.log("1. sum of n number where n is natural number");
var n =7;
var y =0
for( i=0;i<=n;i++){
y=y+i
}
console.log(y)


console.log("2. print the table of n ")
var q=10
for(i=1;i<=q;i++){
    console.log(q*i)
}

console.log("3. Check it is prime or not ")
a=7;
for(i=2;i<a;i++){
  if(a%i==0){
    console.log("this is not prime number")
    break;
  }
  else{
    console.log("this is prime number",a)
    break;
    
  }
}
console.log("4. find the factor of number") 
var w=9
for(i=1;i<=w;i++){
  if(w%i==0 ){
    console.log(i+" is the fator of "+n)
  }
}

console.log("5. find the  sum of all digit of a number ")
var v=121
var b=0;
while(v>0){
  var t=v%10;
  b=b+t
  v=Math.floor(a/10)
}
console.log(b)

console.log("6. check the number wheather it is arm strong or not ")
var st="153"
var s=0

for(i=0;i<st.length;i++){
  s= s+st[i]*st[i]*st[i]
}
if(s==Number(st)){
  console.log("this is a armstrong number")
}
else{
  console.log("this is not armstrong number",)
}
