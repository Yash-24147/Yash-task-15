function fox(arr){
  var a=0
  for(i=0;i<arr.length;i++){
    if(arr[i]>a){
     a=arr[i]
    }
  }
  return a;
}
console.log("Mamimum number is ",fox([1,2,3,4,5,6]))


console.log("Calcuate the sum of all number in array")

var fox1= function(lol){
var b=0  
  for(i=0;i<lol.length;i++){
    b=b+lol[i]
  }
  return b
}
var f=fox1([12,13,14,15])
console.log("Sum of all number is ",f)

console.log("Chcek the number is odd ")

var d=(odd)=>{
  var c=0
  var check=[]
  for(i=0;i<odd.length;i++){
    if(odd[i]%2!=0){
      check.unshift(odd[i])
    }
  }
  return check.length;
}
var t=d([1,2,3,4,5,6,7])
console.log("total odd is ",t)
